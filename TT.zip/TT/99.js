const { Client } = require('discord.js-selfbot-v13');
const client = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client2 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client3 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client4 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client5 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client6 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client7 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client8 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client9 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const client11 = new Client({ ws: { properties: { $browser: "Discord iOS" }} });
const time = [10000, 11000, 12000, 13000, 14000];

client.on('1ready', async () => {
  console.log(`${client.user.username} is ready!`);
})
client2.on('2ready', async () => {
  console.log(`${client2.user.username} is ready!`);
})
client3.on('3ready', async () => {
  console.log(`${client3.user.username} is ready!`);
})
client4.on('4ready', async () => {
  console.log(`${client4.user.username} is ready!`);
})
client5.on('5ready', async () => {
  console.log(`${client5.user.username} is ready!`);
})
client6.on('6ready', async () => {
  console.log(`${client6.user.username} is ready!`);
})
client7.on('6ready', async () => {
  console.log(`${client7.user.username} is ready!`);
})
client8.on('6ready', async () => {
  console.log(`${client8.user.username} is ready!`);
})
client9.on('6ready', async () => {
  console.log(`${client9.user.username} is ready!`);
})
client11.on('6ready', async () => {
  console.log(`${client11.user.username} is ready!`);
})
client12.on('6ready', async () => {
  console.log(`${client11.user.username} is ready!`);
})

                      ////////////////////////////////////////life////////////////////
                      client.on('messageCreate', message => {
                        const content = message.content.toLocaleLowerCase()
                        if (message.content === 'عيالي')
                        if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                        if(message.channel.id === '1201155513954615316') {
                          setTimeout(() => {
                            message.reply("هلا دادي");
                        }, time[Math.floor(Math.random() * time.length)]);
                        }
                        });
                      client2.on('messageCreate', message => {
                        const content = message.content.toLocaleLowerCase()
                        if (message.content === 'عيالي')
                        if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                        if(message.channel.id === '1201155513954615316') {
                          setTimeout(() => {
                            message.reply("هلا دادي");
                        }, time[Math.floor(Math.random() * time.length)]);
                        }
                        });
                        client3.on('messageCreate', message => {
                          const content = message.content.toLocaleLowerCase()
                          if (message.content === 'عيالي')
                          if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                          if(message.channel.id === '1201155513954615316') {
                            setTimeout(() => {
                              message.reply("هلا دادي");
                          }, time[Math.floor(Math.random() * time.length)]);
                          }
                          });
                          client4.on('messageCreate', message => {
                            const content = message.content.toLocaleLowerCase()
                            if (message.content === 'عيالي')
                            if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                            if(message.channel.id === '1201155513954615316') {
                              setTimeout(() => {
                                message.reply("هلا دادي");
                            }, time[Math.floor(Math.random() * time.length)]);
                            }
                            });
                            client5.on('messageCreate', message => {
                              const content = message.content.toLocaleLowerCase()
                              if (message.content === 'عيالي')
                              if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                              if(message.channel.id === '1201155513954615316') {
                                setTimeout(() => {
                                  message.reply("هلا دادي");
                              }, time[Math.floor(Math.random() * time.length)]);
                              }
                              });
                              client6.on('messageCreate', message => {
                                const content = message.content.toLocaleLowerCase()
                                if (message.content === 'عيالي')
                                if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                                if(message.channel.id === '1201155513954615316') {
                                  setTimeout(() => {
                                    message.reply("هلا دادي");
                                }, time[Math.floor(Math.random() * time.length)]);
                                }
                                });
                                client7.on('messageCreate', message => {
                                  const content = message.content.toLocaleLowerCase()
                                  if (message.content === 'عيالي')
                                  if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                                  if(message.channel.id === '1201155513954615316') {
                                    setTimeout(() => {
                                      message.reply("هلا دادي");
                                  }, time[Math.floor(Math.random() * time.length)]);
                                  }
                                  });
                                  client8.on('messageCreate', message => {
                                    const content = message.content.toLocaleLowerCase()
                                    if (message.content === 'عيالي')
                                    if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                                    if(message.channel.id === '1201155513954615316') {
                                      setTimeout(() => {
                                        message.reply("هلا دادي");
                                    }, time[Math.floor(Math.random() * time.length)]);
                                    }
                                    });
                                    client9.on('messageCreate', message => {
                                      const content = message.content.toLocaleLowerCase()
                                      if (message.content === 'عيالي')
                                      if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                                      if(message.channel.id === '1201155513954615316') {
                                        setTimeout(() => {
                                          message.reply("هلا دادي");
                                      }, time[Math.floor(Math.random() * time.length)]);
                                      }
                                      });
                                        client11.on('messageCreate', message => {
                                          const content = message.content.toLocaleLowerCase()
                                          if (message.content === 'عيالي')
                                          if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
                                          if(message.channel.id === '1201155513954615316') {
                                            setTimeout(() => {
                                              message.reply("هلا دادي");
                                          }, time[Math.floor(Math.random() * time.length)]);
                                          }
                                          });
//client.login('MTE5NzYyNTAwNzg0OTg2NTI3OQ.GAWTof.Cuh3EVWprm6l4xDKLmgBIB5ZCVV2rP1Rpz7nUI','MTE4MDYwNTY5NDc5MDA3ODQ4Nw.GUwHAc.7ke0nWmJLg-Qqt8bhXm-pNcGgAhYHYHbvq0KLY');
client.login("MTIwMTg0MTkyODY1MjczNDU1NQ.GSyLds.GP64EJ_LJDQlKI0nv3zu_dultDKe4VVxMum8Nc")
client2.login("MTIwMTg0NDU1NjI0MTMxMzk1Nw.G8JWzT.QEOipTmKglslP5UtPelq7GPiaijSLYmkGw9gxI")
client3.login("MTIwMTg0NTI5NDEyODQzNTIxMw.GrJb82.GCB-o7SfGabtQlKsaCJ4Y6-tP4ey51MepZEbco")
client4.login("MTIwMTg0NjY4ODg2MDYxODc4Mw.GDSwJS._dBXhNCqv4laz3umvirnd8I-Kf96bF_FwTHlqs")
client5.login("MTIwMTg0NTk0NTgxMDMwOTE4NQ.GhRpjD.o7nkecUNichc1fnMV7L51TjPnzDs3F5RGK-UKc")
client6.login("MTIwMTg0OTA5MzIyMDIwODY0Mg.G1SYXV.2R7-F-jCamigdJEMPcpOJcu5fqrHKnVyz3E4t8")
client7.login("MTIwMTg1MDExMTkyODU3NDAwMg.GbZM6N.yFInVQeIoBsiPAeEHdwZYEMWmu7Ruvivpsa5Gw")
client8.login("MTIwMTg1MTEyMDgwOTY3NjgwMQ.GmgLds.0MQlK4UW_mHJ5ROZku_lKhsdLY7l5pf8bUHbUM")
client9.login("MTIwMTg1MjA5MTI3NTE0OTM1Mg.GD6rPb.Bsd7kuXbEx5fmXweHJCekgjqMu54icSXStbC8w")
client11.login("MTIwMTg1NDM2MTQwNDQ0ODc4MA.GRLG6Q.PSsmfH2swT9pqP8na5SfJdWxiHjBkvsDgdtnZ0")


