const { Client } = require('discord.js-selfbot-v13');
const client = new Client({
    checkUpdate: true,
});

client.on("ready", async () => {
    console.log(` ${client.user.username} is now redy`);
    global.startTime = new Date();
})

client.on('messageCreate', message => {
    if (message.content === "$")
    if (message.channel.id === '1201155513954615316')
    if (message.author.id === '1076128293721489418') { 
      const interval = setInterval (function () {
        message.channel.send("عيالي")
      }, 360 * 1000); 
    }
});
client.login("MTE4MzY5ODEzMzE5MzA4NTAyMQ.GThZdZ.svyfocyKoskjtlgX8pjXor_oOE4H81E3S81ou4")
