const
  discord = require("discord.js-selfbot-v13");
 
function reloadPresence(client) {
    const activity = new discord.RichPresence()
      //more command https://discordjs-self-v13.netlify.app/#/docs/docs/main/class/RichPresence or https://github.com/aiko-chan-ai/discord.js-selfbot-v13/blob/main/Document/RichPresence.md
        .setApplicationId("1119170929747050506") //You can replace with your own bot application id
        .setType("LISTENING") //PLAYING, STREAMING, LISTENING
        .setName("spotify") //name of your activity
        .setDetails("Adele") //detail activity
        .setStartTimestamp(global.startTime)
        .setAssetsLargeImage("https://cdn.discordapp.com/attachments/1199960280143237171/1200795889007087626/cc415c918a6f2c7b.jpg?ex=65c77b51&is=65b50651&hm=d8f59fd9fe74927c1b05591ad6649d51af450564d74b2a6a379ae0efc305b666&")
        .setAssetsLargeText("adele")
        .setAssetsSmallImage("https://cdn.discordapp.com/attachments/1199960280143237171/1200795889007087626/cc415c918a6f2c7b.jpg?ex=65c77b51&is=65b50651&hm=d8f59fd9fe74927c1b05591ad6649d51af450564d74b2a6a379ae0efc305b666&")
        .setAssetsSmallText("new alpum")
        .addButton('spotify', "https://open.spotify.com/intl-ar/artist/4dpARuHxo51G3z768sgnrY")
    client.user.setActivity(activity.toJSON())
    client.user.setStatus("dnd")
};
module.exports = reloadPresence;