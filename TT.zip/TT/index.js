const { joinVoiceChannel } = require('@discordjs/voice')
const { Client } = require('discord.js-selfbot-v13')
const { logs } = require('more-consoles')
const { guildId, channelId, autoClaim } = require('./config')
const { kalive } = require('./kalive')
require('dotenv').config()
const statuses = [
  'online',
  'idle',
  'dnd',
  'invisible',
];
var listOfConnections = []
// DO NOT TOUCH ABOVE OTHERWISE THE CODE WON'T WORK
//
//
// YOU MAY CHANGE THE FOLLOWING IF YOU KNOW WHAT YOU'RE DOING
async function run(token) {
  try {
    const rand = Math.round(Math.random());
    if (!guildId || !channelId) return console.log('please make sure that the server ID and channel ID are provided in ./config.js');
    const client = new Client({
      checkUpdate: false,
      autoRedeemNitro: autoClaim || false,
      ws: {
        properties: {
          browser: rand ? 'Discord iOS' : 'Discord desktop'
        }
      }
    })
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
    client.on('ready', async () => {
      logs(`logged in as ${client.user.username}`, client)
      client.user.setStatus(randomStatus);
      const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId)
      if (!guild) return console.log(`${client.user.username} Guild not found`);
      const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId)
      if (!channel) return console.log(`${client.user.username} Channel not found`);
      if (!channel.joinable) return console.log(`${client.user.username} Doesn't have perms to the channel`);
      const mute = Math.round(Math.random() * 10);
      setInterval(async () => {
        const clientMem = guild.members.resolve(client.user.id)
        if (!clientMem.voice.channelId) {
          await client.channels.fetch(channelId)
            .then(channel => {
              var connection = joinVoiceChannel({
                channelId: channelId,
                guildId: guildId,
                group: client.user.id,
                adapterCreator: channel.guild.voiceAdapterCreator,
                selfDeaf: true,
                selfMute: true
              });
              listOfConnections.push(connection);
            }).then(() => {
              console.log('Connected to Channel | ' + client.user.username, ' | ', client.user.id)
            })
            .catch((err) => {
              console.log('can\'t access channel | ' + client.user.username, ' | ', client.user.id)
              console.log(err);
            })
        }

      }, 1000);
      process.once('SIGINT', () => {
        for (const aConnection of listOfConnections) {
          aConnection.destroy()
        }
        process.exit(0);
      });

    })
  
    await sleep(700)
    client.login(token).catch((err) => {
      console.log('Make sure that the token is correct');
      console.log(err);
    })
  } catch (err) {
    console.log(err);
  }

}
async function main() {
  for (let i = 1; process.env[`TOKEN${i}`]; i++) {
    const token = process.env[`TOKEN${i}`].toString()
    if(token.length == 0) return console.log(`TOKEN${i} is empty`)
    const tokenRegex = /[\w-]{24}\.[\w-]{6}\.[\w-]{27}/;
    if (token.match(tokenRegex)) {
      run(token)
    } else {
      console.log(`TOKEN${i} doesn't look like a valid discord token`);
    }
    await sleep(700)
  }
}
main()
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
kalive()